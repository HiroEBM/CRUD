
import java.sql.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.io.FileFilter;
import java.io.FileOutputStream;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

public class productForm extends javax.swing.JFrame {


    public productForm() {
        initComponents();
        Connect();
        LoadProductNo();
        Fetch();
       
    }
    Connection con; 
    PreparedStatement pst;
    ResultSet rs;
    
    public void Connect(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/javacrud","root","");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(productForm.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
    
public void LoadProductNo(){
        try {
            pst = con.prepareStatement("SELECT id FROM product_tbl");
            rs = pst.executeQuery();
            txtpid.removeAllItems();
            while(rs.next()){
                txtpid.addItem(rs.getString(1));
            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(productForm.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    
   private void Fetch(){
    try {
    int q;
    pst = con.prepareStatement("SELECT * FROM product_tbl");
    rs = pst.executeQuery();
    ResultSetMetaData rss = rs.getMetaData();
    q = rss.getColumnCount();
    
    DefaultTableModel df = (DefaultTableModel)jTable1.getModel(); 
    df.setRowCount(0);
    while(rs.next()){
       Vector v2 =  new Vector();
        for (int a=1; a<=q; a++){
            v2.add(rs.getString("id"));
            v2.add(rs.getString("pname"));
            v2.add(rs.getString("price"));
            v2.add(rs.getString("qty"));
            v2.add(rs.getString("amount"));
            v2.add(rs.getString("sukle"));
       
        
            }    
         df.addRow(v2);
        }
    } 
    catch (SQLException ex) {
            Logger.getLogger(productForm.class.getName()).log(Level.SEVERE, null, ex);
        }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtPname = new javax.swing.JTextField();
        txtPrice = new javax.swing.JTextField();
        txtQty = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtAmount = new javax.swing.JTextField();
        txtSukle = new javax.swing.JTextField();
        txtpid = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        btnSearch = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        btnCompute = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnExportCSV = new javax.swing.JButton();
        btnPDF = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Product Name:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Product Price:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Product Qty:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Change:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Amount:");

        txtSukle.setEditable(false);

        txtpid.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Product Id");

        btnSearch.setBackground(new java.awt.Color(255, 255, 255));
        btnSearch.setForeground(new java.awt.Color(0, 0, 0));
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 768, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 79, Short.MAX_VALUE)
        );

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("EJ Sari Sari Store");

        btnCompute.setBackground(new java.awt.Color(204, 255, 255));
        btnCompute.setForeground(new java.awt.Color(0, 0, 0));
        btnCompute.setText("Compute");
        btnCompute.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComputeActionPerformed(evt);
            }
        });

        btnAdd.setBackground(new java.awt.Color(153, 255, 153));
        btnAdd.setForeground(new java.awt.Color(0, 0, 0));
        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnUpdate.setBackground(new java.awt.Color(102, 204, 255));
        btnUpdate.setForeground(new java.awt.Color(0, 0, 0));
        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnDelete.setBackground(new java.awt.Color(255, 51, 51));
        btnDelete.setForeground(new java.awt.Color(0, 0, 0));
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnExportCSV.setBackground(new java.awt.Color(255, 255, 255));
        btnExportCSV.setForeground(new java.awt.Color(0, 0, 0));
        btnExportCSV.setText("Export to CSV");
        btnExportCSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportCSVActionPerformed(evt);
            }
        });

        btnPDF.setBackground(new java.awt.Color(255, 255, 255));
        btnPDF.setForeground(new java.awt.Color(0, 0, 0));
        btnPDF.setText("Export PDF");
        btnPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDFActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnAdd)
                .addGap(18, 18, 18)
                .addComponent(btnUpdate)
                .addGap(18, 18, 18)
                .addComponent(btnDelete)
                .addGap(18, 18, 18)
                .addComponent(btnExportCSV)
                .addGap(18, 18, 18)
                .addComponent(btnPDF)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdd)
                    .addComponent(btnUpdate)
                    .addComponent(btnDelete)
                    .addComponent(btnExportCSV)
                    .addComponent(btnPDF))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Product Name", "Product Price", "Product Qty", "Amount", "Change"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(txtPrice, javax.swing.GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE)
                    .addComponent(txtQty)
                    .addComponent(txtPname))
                .addGap(91, 91, 91)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addGap(163, 163, 163))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btnCompute))
                            .addComponent(txtSukle, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(355, 355, 355))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtAmount)
                                .addGap(132, 132, 132)
                                .addComponent(txtpid, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnSearch)))
                        .addGap(24, 24, 24))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 839, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel7)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSearch)
                                    .addComponent(txtpid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(50, 50, 50))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtPname, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtSukle, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnCompute))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtQty, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
     
        if(txtPname.getText().isEmpty()){
        JOptionPane.showMessageDialog(this,"Product name is Required!!");
        }else if(txtPrice.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this,"Product Price is Required!!");
        }else if(txtQty.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this,"Product Quantity is Required!!"); 
        }else if(txtAmount.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this,"Amount is Required!!");
        }else{
                
        try{
       String pname = txtPname.getText();
       String price = txtPrice.getText();
       String qty = txtQty.getText(); 
       String amount = txtAmount.getText();
       String sukle= txtSukle.getText(); 
     
      
       pst = con.prepareStatement("INSERT INTO product_tbl (pname, price, qty, amount, sukle) VALUES (?,?,?,?,?)");
       pst.setString(1,pname);
       pst.setString(2,price);
       pst.setString(3,qty);
       pst.setString(4,amount);
       pst.setString(5,sukle);
    
       
       int k = pst.executeUpdate();
       
       if (k == 1){
       JOptionPane.showMessageDialog(this,"Record Added!! Successfully");
       txtPname.setText("");
       txtPrice.setText("");
       txtQty.setText("");
       txtAmount.setText("");
       txtSukle.setText("");
 
       Fetch();
       LoadProductNo();
       
       }
      }
      catch (SQLException ex) {
            Logger.getLogger(productForm.class.getName()).log(Level.SEVERE, null, ex);
        }
                }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        try{  
        String pid = txtpid.getSelectedItem().toString();
            pst = con.prepareStatement("SELECT * FROM product_tbl WHERE id=?");

            pst.setString(1, pid);
            rs = pst.executeQuery();
            
            if(rs.next()== true){
                txtPname.setText(rs.getString(2));
                txtPrice.setText(rs.getString(3));
                txtQty.setText(rs.getString(4));
                txtAmount.setText(rs.getString(5));
                txtSukle.setText(rs.getString(6));
                
            }
            else{
                JOptionPane.showMessageDialog(this, "No Record Found...");
            }
        }
            catch (SQLException ex){
            Logger.getLogger(productForm.class.getName()).log(Level.SEVERE, null, ex);
        }       
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {  
       
        if(txtPname.getText().isEmpty()){
        JOptionPane.showMessageDialog(this,"Product name is Required!!");
        }else if(txtPrice.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this,"Product Price is Required!!");
        }else if(txtQty.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this,"Product Quantity is Required!!");  
        }else if(txtAmount.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this,"Amount is Required!!");
        }else{
       
        try {  
         String pname = txtPname.getText();
         String price = txtPrice.getText();
         String qty = txtQty.getText();
         String amount = txtAmount.getText();
         String sukle = txtSukle.getText();
         String pid = txtpid.getSelectedItem().toString();

pst = con.prepareStatement("UPDATE product_tbl SET pname=?, price=?, qty=?, amount =?, sukle=? WHERE id=?");

pst.setString(1, pname);
pst.setString(2, price);
pst.setString(3, qty);
pst.setString(4, amount);
pst.setString(5, sukle);
pst.setString(6, pid);



int k = pst.executeUpdate();

if (k == 1) {
    JOptionPane.showMessageDialog(this, "Record successfully updated!");
    txtPname.setText("");
    txtPrice.setText("");
    txtQty.setText("");
     txtAmount.setText("");
    txtSukle.setText("");
    txtPname.requestFocus();
   Fetch();
       LoadProductNo();
}

        
    }
         catch (SQLException ex){
            Logger.getLogger(productForm.class.getName()).log(Level.SEVERE, null, ex);
        }       
    }

    }

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
      try { 
            
            String pid = txtpid.getSelectedItem().toString();
            pst = con.prepareStatement("DELETE FROM product_tbl WHERE id=?");
            pst.setString(1,pid);
            int k = pst.executeUpdate();
            if (k == 1) {
    JOptionPane.showMessageDialog(this, "Record successfully Delete!");
            txtPname.setText("");
            txtPrice.setText("");
            txtQty.setText("");
            txtAmount.setText("");
            txtSukle.setText("");
            txtPname.requestFocus();
           Fetch();
       LoadProductNo();
            }else{
                 JOptionPane.showMessageDialog(this, "Record failed to Delete!");
        }
        }catch (SQLException ex){
            Logger.getLogger(productForm.class.getName()).log(Level.SEVERE, null, ex);
      }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnExportCSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportCSVActionPerformed
       
        String filename = "C:\\ExportFile\\ExportFileJava.csv";
        
        try{
            FileWriter fw = new FileWriter(filename);
            pst = con.prepareStatement("SELECT * FROM product_tbl");
             rs = pst.executeQuery();   
             
             while(rs.next()){
                   
                 fw.append(rs.getString(1));
                 fw.append(',');
                 fw.append(rs.getString(2));
                 fw.append(',');
                 fw.append(rs.getString(3));
                 fw.append(',');
                 fw.append(rs.getString(4));
                 fw.append(',');
                 fw.append(rs.getString(5));
                 fw.append(',');
                 fw.append(rs.getString(6));
                 fw.append('\n');
                 
                
             }
              JOptionPane.showMessageDialog(this, "CSV File is exported!!");
             fw.flush(); 
             fw.close();
        }
        catch (IOException | SQLException ex){
            Logger.getLogger(productForm.class.getName()).log(Level.SEVERE, null, ex);
        
        }
        
        
    }//GEN-LAST:event_btnExportCSVActionPerformed

    private void btnPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDFActionPerformed
        try {
            // TODO add your handling code here:
            pst = con.prepareStatement("SELECT * FROM product_tbl");
            rs = pst.executeQuery();
            
            
            Document PDFreport = new Document();
            PdfWriter.getInstance(PDFreport, new FileOutputStream("C:\\ExportFile\\OutputReportJava.pdf"));
            
            PDFreport.open();
             
            PdfPTable PDFTable = new PdfPTable(6);
            PdfPCell table_cell;
            
            while (rs.next()){
                
            String pid = rs.getString("id");
            table_cell = new PdfPCell (new Phrase(pid));
            PDFTable.addCell(table_cell);
            
            String ppname = rs.getString("pname");   
            table_cell = new PdfPCell (new Phrase(ppname));
            PDFTable.addCell(table_cell);
            
            String pprice = rs.getString("price");   
            table_cell = new PdfPCell (new Phrase(pprice));
            PDFTable.addCell(table_cell);
            
            String pqty = rs.getString("qty");   
            table_cell = new PdfPCell (new Phrase(pqty));
            PDFTable.addCell(table_cell);
            
            String amount = rs.getString("amount");   
            table_cell = new PdfPCell (new Phrase(amount));
            PDFTable.addCell(table_cell);
            
            String sukle = rs.getString("sukle");   
            table_cell = new PdfPCell (new Phrase(sukle));
            PDFTable.addCell(table_cell);
              
            }
            JOptionPane.showMessageDialog(this, "PDF File is exported!!");
            PDFreport.add(PDFTable);
            PDFreport.close();
            
            } catch (SQLException | FileNotFoundException | DocumentException ex) {
            Logger.getLogger(productForm.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_btnPDFActionPerformed

    private void btnComputeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComputeActionPerformed
       
        if(txtPname.getText().isEmpty()){
        JOptionPane.showMessageDialog(this,"Product name is Required!!");
        }else if(txtPrice.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this,"Product Price is Required!!");
        }else if(txtQty.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this,"Product Quantity is Required!!");  
        }else if(txtAmount.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this,"Amount is Required!!");
        }else{
            
     String amount = txtAmount.getText();
    String price = txtPrice.getText();
    String qty = txtQty.getText();

    try {
        double priceValue = Double.parseDouble(price);
        double qtyValue = Double.parseDouble(qty);
        double amountValue = Double.parseDouble(amount);
        double mul = priceValue * qtyValue;
        
        if(amountValue >= mul){
        
        double sukle = amountValue - mul;
        txtSukle.setText(String.format("%.2f", sukle));
        }
        else{
         JOptionPane.showMessageDialog(this, "The Amount is not Enough");
        }
    } catch (NumberFormatException e) {
        showError("Invalid input. Please enter a numeric value.");
    }
        }
    }//GEN-LAST:event_btnComputeActionPerformed
                                    

  
    public static void main(String args[]) { 
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginForm().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCompute;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnExportCSV;
    private javax.swing.JButton btnPDF;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtAmount;
    private javax.swing.JTextField txtPname;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextField txtQty;
    private javax.swing.JTextField txtSukle;
    private javax.swing.JComboBox<String> txtpid;
    // End of variables declaration//GEN-END:variables

    private void showError(String invalid_input_Please_enter_a_numeric_temp) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
